{
    "configar": {
        "branding": {
            "main": {
                "label": "main",
                "image": "img\/logo_GGG_202x50.png",
                "url": "http:\/\/www.123games.co.kr\/Main",
                "style": "",
                "width": "202",
                "height": "50",
                "mime": "image\/png",
                "type": "png",
                "handler": "newTab",
                "blacklisted": false
            },
            "more_games": {
                "label": "more_games",
                "image": null,
                "url": "http:\/\/www.123games.co.kr\/Main",
                "style": "",
                "width": null,
                "height": null,
                "mime": null,
                "type": null,
                "handler": "newTab",
                "blacklisted": false
            },
            "logo": {
                "label": "logo",
                "image": "img\/logo_GGG_202x50.png",
                "url": "http:\/\/www.123games.co.kr\/Main",
                "style": "",
                "width": "202",
                "height": "50",
                "mime": "image\/png",
                "type": "png",
                "handler": "newTab",
                "blacklisted": true
            },
            "splash_screen": {
                "label": "splash_screen",
                "image": "place_holder_string",
                "url": "http:\/\/www.123games.co.kr\/Main",
                "style": "",
                "width": "0",
                "height": "0",
                "mime": "image\/png",
                "type": "png",
                "handler": "newTab",
                "blacklisted": true
            }
        }
    }
}
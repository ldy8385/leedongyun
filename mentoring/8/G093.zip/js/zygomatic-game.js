window.zygomatic = {
	settings: {
		skipGoogleAdDomains: [
			'sda.4399.com'
		]
	}
};
